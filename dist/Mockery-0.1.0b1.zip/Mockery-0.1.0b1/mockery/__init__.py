#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# author: jjpan

VERSION = '0.1.0b1'
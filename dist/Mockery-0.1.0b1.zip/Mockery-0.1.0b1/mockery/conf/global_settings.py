#!/usr/bin/env python3
# -*- coding: utf-8 -*-
DEBUG = False

# Request timeout, default 30s
TIME_OUT = 30

# Test data path
DATA_PATH = './'

# Test data dir name
DATA_DIR = 'data'

# define default convert type
DEFINE_DEFAULT_CONVERT = 'json'